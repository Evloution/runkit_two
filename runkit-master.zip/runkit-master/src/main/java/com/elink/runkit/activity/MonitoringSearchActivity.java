package com.elink.runkit.activity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import com.elink.runkit.R;

/**
 * @author Evloution
 * @date 2020-01-16
 * @email 15227318030@163.com
 * @description 查询监测点界面
 */
public class MonitoringSearchActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_monitoringsearch);
    }
}
