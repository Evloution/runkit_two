package com.elink.runkit.constants;

/**
 * @Description：
 * @Author： Evloution_
 * @Date： 2019-11-26
 * @Email： 15227318030@163.com
 */
public class Constants {
    // 服务器地址
    public static final String BASE_URL = "http://elinkyou.51vip.biz:3391/";

    // 设备在线率
    public static double DEVICES_ONLINE = 0;
}
